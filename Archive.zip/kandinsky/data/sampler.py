"""Multi-resolution multi-task batch samplers for Kandinsky-5 training.

Ensures each batch contains only samples from the same (task, bucket) pair,
which is required for batched training with variable resolutions.

Adapted from HunyuanVideo 1.5 sampler.py.
"""

import os
from typing import Iterator, List, Optional

import torch
import torch.distributed as dist
from torch.utils.data import Sampler


class MultiResMultiTaskSampler(Sampler):
    """Single-process sampler that groups samples by (task, resolution bucket)."""

    TASK_TO_BATCH_SIZE = {
        "tv2v": 1,
        "ti2i": 4,
        "t2v": 1,
        "t2i": 4,
        "style_transfer": 1,
        "prop": 1,
    }

    def __init__(
        self,
        dataset,
        video_batch_size: int = 1,
        image_batch_size: int = 4,
        gen_video_batch_size: int = 1,
        gen_image_batch_size: int = 4,
        shuffle: bool = True,
        seed: int = 42,
        drop_last: bool = True,
    ):
        self.dataset = dataset
        self.shuffle = shuffle
        self.seed = seed
        self.drop_last = drop_last
        self.epoch = 0

        self.task_bucket_to_indices = dataset.task_bucket_to_indices
        self.task_buckets = dataset.task_buckets

        self.task_to_batch_size = {
            "tv2v": video_batch_size,
            "style_transfer": video_batch_size,
            "prop": video_batch_size,
            "ti2i": image_batch_size,
            "t2v": gen_video_batch_size,
            "t2i": gen_image_batch_size,
        }

        self.task_bucket_batches = {}
        total_batches = 0
        for task in sorted(self.task_buckets.keys()):
            bs = self.task_to_batch_size.get(task, video_batch_size)
            for bucket in sorted(self.task_buckets[task]):
                key = (task, bucket)
                indices = self.task_bucket_to_indices[key]
                n = len(indices) // bs
                if not self.drop_last and len(indices) % bs > 0:
                    n += 1
                self.task_bucket_batches[key] = n
                total_batches += n
        self.total_batches = total_batches

    def _create_batches(self, indices, batch_size, generator):
        indices = list(indices)
        if self.shuffle:
            perm = torch.randperm(len(indices), generator=generator).tolist()
            indices = [indices[i] for i in perm]
        batches = []
        for i in range(0, len(indices), batch_size):
            batch = indices[i : i + batch_size]
            if not self.drop_last or len(batch) == batch_size:
                batches.append([int(x) for x in batch])
        return batches

    def __iter__(self) -> Iterator[List[int]]:
        g = torch.Generator()
        g.manual_seed(self.seed + self.epoch)

        all_batches = []
        for task in sorted(self.task_buckets.keys()):
            bs = self.task_to_batch_size.get(task, 1)
            for bucket in sorted(self.task_buckets[task]):
                indices = self.task_bucket_to_indices[(task, bucket)]
                if len(indices) > 0:
                    all_batches.extend(self._create_batches(indices, bs, g))

        if self.shuffle:
            perm = torch.randperm(len(all_batches), generator=g).tolist()
            all_batches = [all_batches[i] for i in perm]

        return iter(all_batches)

    def __len__(self) -> int:
        return self.total_batches

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch


class MultiResMultiTaskSamplerDistributed(Sampler):
    """Distributed sampler that groups samples by (task, resolution bucket).

    All ranks see the same batch ordering (seeded by epoch) so that each
    batch contains samples from the same (task, bucket) pair.
    """

    TASK_TO_BATCH_SIZE = {
        "tv2v": 1,
        "ti2i": 4,
        "t2v": 1,
        "t2i": 4,
        "style_transfer": 1,
        "prop": 1,
    }

    def __init__(
        self,
        dataset,
        video_batch_size: int = 1,
        image_batch_size: int = 4,
        gen_video_batch_size: int = 1,
        gen_image_batch_size: int = 4,
        shuffle: bool = True,
        seed: int = 42,
        drop_last: bool = True,
        num_replicas: Optional[int] = None,
        rank: Optional[int] = None,
    ):
        if num_replicas is None:
            if dist.is_available() and dist.is_initialized():
                self.num_replicas = dist.get_world_size()
            else:
                ws = os.environ.get("WORLD_SIZE")
                self.num_replicas = int(ws) if ws else 1
        else:
            self.num_replicas = num_replicas

        if rank is None:
            if dist.is_available() and dist.is_initialized():
                self.rank = dist.get_rank()
            else:
                r = os.environ.get("RANK")
                self.rank = int(r) if r else 0
        else:
            self.rank = rank

        self.dataset = dataset
        self.shuffle = shuffle
        self.seed = seed
        self.drop_last = drop_last
        self.epoch = 0

        self.task_bucket_to_indices = dataset.task_bucket_to_indices
        self.task_buckets = dataset.task_buckets

        self.task_to_batch_size = {
            "tv2v": video_batch_size,
            "style_transfer": video_batch_size,
            "prop": video_batch_size,
            "ti2i": image_batch_size,
            "t2v": gen_video_batch_size,
            "t2i": gen_image_batch_size,
        }

        self.task_bucket_batches = {}
        global_total = 0
        for task in sorted(self.task_buckets.keys()):
            bs = self.task_to_batch_size.get(task, video_batch_size)
            for bucket in sorted(self.task_buckets[task]):
                key = (task, bucket)
                indices = self.task_bucket_to_indices[key]
                n = len(indices) // bs
                if not self.drop_last and len(indices) % bs > 0:
                    n += 1
                self.task_bucket_batches[key] = n
                global_total += n

        self.global_total_batches = global_total
        self.num_batches_per_replica = (
            (self.global_total_batches + self.num_replicas - 1) // self.num_replicas
        )

        if self.rank == 0:
            print(
                f"MultiResMultiTaskSamplerDistributed: "
                f"{self.global_total_batches} global batches, "
                f"{self.num_batches_per_replica} per replica, "
                f"{self.num_replicas} replicas"
            )

    def _create_batches(self, indices, batch_size, generator):
        indices = list(indices)
        if self.shuffle:
            perm = torch.randperm(len(indices), generator=generator).tolist()
            indices = [indices[i] for i in perm]
        batches = []
        for i in range(0, len(indices), batch_size):
            batch = indices[i : i + batch_size]
            if not self.drop_last or len(batch) == batch_size:
                batches.append([int(x) for x in batch])
        return batches

    def __iter__(self) -> Iterator[List[int]]:
        g = torch.Generator()
        g.manual_seed(self.seed + self.epoch)

        all_batches = []
        for task in sorted(self.task_buckets.keys()):
            bs = self.task_to_batch_size.get(task, 1)
            for bucket in sorted(self.task_buckets[task]):
                indices = self.task_bucket_to_indices[(task, bucket)]
                if len(indices) > 0:
                    all_batches.extend(self._create_batches(indices, bs, g))

        if self.shuffle:
            perm = torch.randperm(len(all_batches), generator=g).tolist()
            all_batches = [all_batches[i] for i in perm]

        return iter(all_batches)

    def __len__(self) -> int:
        return self.num_batches_per_replica

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch
