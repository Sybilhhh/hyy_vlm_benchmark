#!/usr/bin/env python3
"""
Unified inference script for Kandinsky-5 fine-tuned checkpoints.

Loads a DiT checkpoint into the Kandinsky5UnifiedPipeline and runs inference
over a benchmark CSV. Supports t2v, t2i, ti2i, tv2v, prop task types.

Supports multi-GPU data parallelism via torchrun: each rank loads a full
pipeline on its own GPU and processes a disjoint shard of CSV rows.

The task type is determined per-row from a 'task' column in the CSV.
If the CSV has no 'task' column, a --task fallback must be supplied.

CSV formats:
  - t2v: 'caption' column
  - tv2v: 'video_path' + 'instruction'
  - prop: 'video_path' + 'instruction' + 'guide_image_path' (or --guide_image_base_path + save_name.png)
  - ti2i: 'image_path' (or 'video_path') + 'instruction'
  - t2i: 'caption' column

Usage (single GPU):
    python infer_unified.py \
        --conf_path configs/k5_unified.yaml \
        --dit_checkpoint outputs/unified_run/checkpoint-10/dit.safetensors \
        --csv_path /path/to/benchmark.csv \
        --output_dir outputs/infer/checkpoint-10/bench

Usage (multi-GPU):
    torchrun --nproc_per_node=4 infer_unified.py \
        --conf_path configs/k5_unified.yaml \
        --dit_checkpoint outputs/unified_run/checkpoint-10/dit.safetensors \
        --csv_path /path/to/benchmark.csv \
        --output_dir outputs/infer/checkpoint-10/bench
"""

import argparse
import csv
import logging
import os
from pathlib import Path
from typing import Optional, Tuple

import torch
from omegaconf import OmegaConf

from kandinsky.utils import get_unified_pipeline

# Lucy/Hunyuan-style bucket and frame selection (inference_prop / inference_edit_all_v4)
BUCKET_GROUPS = [
    [(480, 848), (544, 720), (640, 640), (720, 544), (848, 480)],
    [(720, 1280), (832, 1104), (960, 960), (1104, 832), (1280, 720)],
    [(768, 1360), (880, 1184), (1024, 1024), (1184, 880), (1360, 768)],
    [(1088, 1920), (1248, 1664), (1440, 1440), (1664, 1248), (1920, 1088)],
]
STANDARD_FRAME_COUNTS = [49, 81, 121]


def get_video_info(video_path: str) -> Tuple[int, int, int, float]:
    """Return (height, width, num_frames, fps)."""
    import decord
    decord.bridge.set_bridge("torch")
    vr = decord.VideoReader(video_path)
    h, w = vr[0].shape[0], vr[0].shape[1]
    n = len(vr)
    fps = vr.get_avg_fps()
    return h, w, n, fps


def get_bucket(h: int, w: int, max_group: Optional[int] = None) -> Tuple[int, int]:
    """Lucy/Hunyuan-style: pick resolution from BUCKET_GROUPS by pixel count and aspect ratio.
    max_group: if set, limit to first max_group groups (1-based; Hunyuan --group_pixels)."""
    if h == 0 or w == 0:
        return (480, 848)
    groups = BUCKET_GROUPS[:max_group] if max_group is not None else BUCKET_GROUPS
    input_pixels = h * w
    input_ratio = w / h
    best_group = groups[0]
    for group in groups:
        rep_h, rep_w = group[2]
        if rep_h * rep_w <= input_pixels:
            best_group = group
        else:
            break
    best_bucket = None
    min_ratio_diff = float("inf")
    for bucket_h, bucket_w in best_group:
        diff = abs((bucket_w / bucket_h) - input_ratio)
        if diff < min_ratio_diff:
            min_ratio_diff = diff
            best_bucket = (bucket_h, bucket_w)
    return best_bucket or (480, 848)


def get_bucket_from_image(image_path: str, max_group: Optional[int] = None) -> Tuple[int, int]:
    """Hunyuan-style: get bucket from image file (pixel count + aspect ratio)."""
    from PIL import Image
    img = Image.open(image_path).convert("RGB")
    w, h = img.size
    return get_bucket(h, w, max_group)


def get_target_frames(num_frames: int, frame_mode: str = "auto") -> int:
    """Lucy-style: target frame count (49/81/121 or nearest 4k+1)."""
    if frame_mode == "49":
        return 49
    if frame_mode == "81":
        return 81
    if frame_mode == "nearest":
        k = max(0, round((num_frames - 1) / 4))
        return max(1, min(4 * k + 1, 121))
    if abs(num_frames - 49) <= abs(num_frames - 81):
        return 49
    if num_frames < 121:
        return 81
    return 81

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


def _get_dist_info():
    """Return (rank, local_rank, world_size) from torchrun env vars, or (0, 0, 1) for single-GPU."""
    rank = int(os.environ.get("RANK", 0))
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    world_size = int(os.environ.get("WORLD_SIZE", 1))
    return rank, local_rank, world_size


def read_csv(csv_path):
    with open(csv_path, "r") as f:
        reader = csv.DictReader(f)
        return list(reader)


def _resolve_task(row, fallback_task):
    """Get the task from the row's 'task' column, falling back to fallback_task."""
    task = row.get("task_type", "").strip()
    if task:
        return task
    if fallback_task:
        return fallback_task
    raise ValueError(
        f"Row has no 'task' column and no --task fallback was provided. "
        f"Row keys: {list(row.keys())}"
    )


def _mask_distributed_env():
    """Temporarily remove distributed env vars so get_unified_pipeline sees world_size=1.

    For data-parallel inference each rank loads an independent pipeline on its
    own GPU.  We hide the torchrun env so the pipeline constructor doesn't try
    to set up tensor parallelism or collective ops.
    """
    saved = {}
    for key in ("LOCAL_RANK", "WORLD_SIZE", "RANK", "LOCAL_WORLD_SIZE"):
        saved[key] = os.environ.pop(key, None)
    return saved


def _restore_distributed_env(saved):
    for key, val in saved.items():
        if val is not None:
            os.environ[key] = val


# ---------------------------------------------------------------------------
# Core loop: run an already-constructed pipeline over CSV rows
# ---------------------------------------------------------------------------

def run_csv_rows_with_pipeline(
    pipeline,
    csv_path,
    output_dir,
    data_root=None,
    fallback_task=None,
    num_steps=None,
    guidance_weight=None,
    seed=42,
    time_length=5,
    height=None,
    width=None,
    expand_prompts=False,
    max_samples=None,
    guide_image_base_path=None,
    use_prop_bucket=False,
    frame_mode="auto",
    group_pixels=None,
    rank=0,
    world_size=1,
):
    """Iterate over a benchmark CSV and call *pipeline* for each sample.

    This is the shared core used both by the standalone script and by the
    in-training benchmark path.  The caller is responsible for constructing
    (and later cleaning up) the pipeline object.
    """
    os.makedirs(output_dir, exist_ok=True)

    all_rows = read_csv(csv_path)
    if max_samples is not None:
        all_rows = all_rows[:max_samples]

    original_indices = list(range(len(all_rows)))
    my_indices = original_indices[rank::world_size]
    my_rows = [all_rows[i] for i in my_indices]

    total = len(all_rows)
    logger.info(
        f"[rank {rank}/{world_size}] Running inference on "
        f"{len(my_rows)}/{total} samples from {csv_path}"
    )

    for local_idx, (orig_idx, row) in enumerate(zip(my_indices, my_rows)):
        task = _resolve_task(row, fallback_task)

        ext = ".mp4" if task in ("t2v", "tv2v", "prop") else ".png"
        save_path = os.path.join(output_dir, f"{orig_idx:04d}{ext}")

        if os.path.exists(save_path):
            logger.info(f"[{local_idx+1}/{len(my_rows)}] Skipping (exists): {save_path}")
            continue

        if task in ("t2v", "t2i"):
            text = row.get("caption", row.get("instruction", ""))
        else:
            text = row.get("instruction", row.get("caption", ""))

        video_path = None
        if task in ("tv2v", "prop"):
            video_path = row.get("video_path", "") or row.get("video1_path", "")
            if data_root and video_path and not os.path.isabs(video_path):
                video_path = os.path.join(data_root, video_path)
            if not video_path or not os.path.isfile(video_path):
                logger.error(
                    f"[rank {rank}] tv2v/prop requires an existing video_path/video1_path. "
                    f"Skip sample {orig_idx}: missing source video {video_path}"
                )
                continue

        image_path = None
        if task == "ti2i":
            image_path = row.get("image_path", row.get("video_path", ""))
            if data_root and not os.path.isabs(image_path):
                image_path = os.path.join(data_root, image_path)

        guide_image_path = None
        guide_video_path = None
        if task == "prop":
            guide_image_path = row.get("guide_image_path", "")
            if not guide_image_path and guide_image_base_path:
                save_name = row.get("save_name", Path(row.get("video_path", "out")).stem + ".png")
                if not save_name.lower().endswith(".png"):
                    save_name = save_name + ".png"
                guide_image_path = os.path.join(guide_image_base_path, save_name)
            if guide_image_path and not os.path.isabs(guide_image_path) and data_root:
                guide_image_path = os.path.join(data_root, guide_image_path)
            if not guide_image_path or not os.path.isfile(guide_image_path):
                guide_video_path = row.get("video2_path", "")
                if guide_video_path and data_root and not os.path.isabs(guide_video_path):
                    guide_video_path = os.path.join(data_root, guide_video_path)
                if not guide_video_path or not os.path.isfile(guide_video_path):
                    logger.error(
                        f"[rank {rank}] prop requires guide_image_path or video2_path (Hunyuan-style). "
                        f"Skip sample {orig_idx}: missing"
                    )
                    continue
                guide_image_path = None

        logger.info(
            f"[STEP 1][rank {rank}][{local_idx+1}/{len(my_rows)}] "
            f"task={task} text={text[:80]}{'...' if len(text) > 80 else ''}"
        )

        logger.info(
            f"[STEP 2][rank {rank}] Paths for sample {orig_idx}: "
            f"video_path={video_path}, image_path={image_path}, "
            f"guide_image_path={guide_image_path}, save_path={save_path}"
        )

        try:
            logger.info(
                f"[STEP 3][rank {rank}] Building kwargs for sample {orig_idx}"
            )
            prop_height, prop_width, prop_num_frames = height, width, None
            if task == "prop" and use_prop_bucket and video_path and (height is None or width is None):
                try:
                    vh, vw, nf, _ = get_video_info(video_path)
                    prop_height, prop_width = get_bucket(vh, vw, max_group=group_pixels)
                    nf_use = nf
                    if row.get("frames") not in (None, ""):
                        try:
                            nf_use = min(nf, int(row["frames"]))
                        except (ValueError, TypeError):
                            pass
                    prop_num_frames = get_target_frames(nf_use, frame_mode)
                    logger.info(
                        f"[rank {rank}] Lucy-style prop bucket: video {vh}x{vw} {nf}f -> "
                        f"bucket {prop_height}x{prop_width} {prop_num_frames}f"
                    )
                except Exception as e:
                    logger.warning(f"[rank {rank}] use_prop_bucket failed: {e}, using defaults")
            kwargs = dict(
                text=text,
                task_type=task,
                video=video_path,
                image=image_path,
                time_length=time_length,
                height=prop_height,
                width=prop_width,
                seed=seed,
                num_steps=num_steps,
                guidance_weight=guidance_weight,
                expand_prompts=expand_prompts,
                save_path=save_path,
                progress=True,
            )
            if prop_num_frames is not None:
                kwargs["num_frames"] = prop_num_frames
            elif task in ("tv2v", "prop") and row.get("frames") not in (None, ""):
                try:
                    kwargs["num_frames"] = min(
                        time_length * 24 // 4 + 1 if time_length else 81,
                        int(row["frames"]),
                    )
                except (ValueError, TypeError):
                    pass
            if task == "prop":
                if guide_image_path:
                    logger.info(
                        f"[STEP 3.1][rank {rank}] Adding guide_image for sample {orig_idx}: "
                        f"{guide_image_path}"
                    )
                    kwargs["guide_image"] = guide_image_path
                else:
                    logger.info(
                        f"[STEP 3.1][rank {rank}] Adding guide_video (Hunyuan-style) for sample {orig_idx}: "
                        f"{guide_video_path}"
                    )
                    kwargs["guide_video"] = guide_video_path

            logger.info(
                f"[STEP 4][rank {rank}] Calling pipeline for sample {orig_idx} "
                f"with task={task}"
            )
            pipeline(**kwargs)
            logger.info(f"[STEP 5] Saved output for sample {orig_idx}: {save_path}")
        except Exception:
            logger.exception(
                f"[ERROR] Failed on sample {orig_idx} during pipeline execution"
            )
            continue

    logger.info(f"[rank {rank}/{world_size}] Done. Outputs in {output_dir}")


# ---------------------------------------------------------------------------
# Standalone entry point: loads pipeline from disk, runs CSV, cleans up
# ---------------------------------------------------------------------------

def run_inference_on_csv(
    conf_path,
    dit_checkpoint,
    csv_path,
    output_dir,
    data_root=None,
    fallback_task=None,
    num_steps=None,
    guidance_weight=None,
    seed=42,
    time_length=5,
    height=None,
    width=None,
    quantized_qwen=False,
    text_token_padding=False,
    expand_prompts=False,
    max_samples=None,
    guide_image_base_path=None,
    use_prop_bucket=False,
    frame_mode="auto",
    group_pixels=None,
    rank=0,
    local_rank=0,
    world_size=1,
):
    """Load a fresh pipeline from a checkpoint file, run CSV inference, clean up."""
    os.makedirs(output_dir, exist_ok=True)

    device = torch.device(f"cuda:{local_rank}")
    torch.cuda.set_device(device)
    offload = world_size == 1

    logger.info(
        f"[rank {rank}/{world_size}] Loading pipeline on {device} from "
        f"config={conf_path}, dit={dit_checkpoint}"
    )

    conf = OmegaConf.load(conf_path)
    conf.model.checkpoint_path = dit_checkpoint

    tmp_conf_path = os.path.join(output_dir, f"_tmp_conf_rank{rank}.yaml")
    OmegaConf.save(conf, tmp_conf_path)

    saved_env = _mask_distributed_env()
    try:
        pipeline = get_unified_pipeline(
            device_map=device,
            conf_path=tmp_conf_path,
            offload=offload,
            quantized_qwen=quantized_qwen,
            text_token_padding=text_token_padding,
        )

        # ----------------------------
        # 🔥 强制统一 pipeline 子模块 dtype 为 float16
        # ----------------------------
        for module_name in ["vae", "dit", "text_encoder"]:
            if hasattr(pipeline, module_name):
                submodule = getattr(pipeline, module_name)
                submodule = submodule.to(torch.float16)
                setattr(pipeline, module_name, submodule)

    finally:
        _restore_distributed_env(saved_env)

    if os.path.exists(tmp_conf_path):
        os.remove(tmp_conf_path)
    logger.info(f"[rank {rank}/{world_size}] Pipeline loaded on {device} with float16")

    run_csv_rows_with_pipeline(
        pipeline=pipeline,
        csv_path=csv_path,
        output_dir=output_dir,
        data_root=data_root,
        fallback_task=fallback_task,
        num_steps=num_steps,
        guidance_weight=guidance_weight,
        seed=seed,
        time_length=time_length,
        height=height,
        width=width,
        expand_prompts=expand_prompts,
        max_samples=max_samples,
        guide_image_base_path=guide_image_base_path,
        use_prop_bucket=use_prop_bucket,
        frame_mode=frame_mode,
        group_pixels=group_pixels,
        rank=rank,
        world_size=world_size,
    )

    del pipeline
    torch.cuda.empty_cache()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="Kandinsky-5 unified inference")

    parser.add_argument("--conf_path", type=str, required=True,
                        help="Path to unified YAML config")
    parser.add_argument("--dit_checkpoint", type=str, required=True,
                        help="Path to fine-tuned dit.safetensors")
    parser.add_argument("--csv_path", type=str, required=True,
                        help="Path to benchmark CSV")
    parser.add_argument("--data_root", type=str, default=None,
                        help="Root directory prepended to relative media paths")
    parser.add_argument("--task", type=str, default=None,
                        choices=["t2v", "t2i", "ti2i", "tv2v", "prop"],
                        help="Fallback task type (used when CSV has no 'task' column)")
    parser.add_argument("--guide_image_base_path", type=str, default=None,
                        help="For prop: base dir for guide images; path = base_path / save_name (e.g. xxx.png)")
    parser.add_argument("--output_dir", type=str, required=True,
                        help="Directory to save generated outputs")

    parser.add_argument("--num_steps", type=int, default=None)
    parser.add_argument("--guidance_weight", type=float, default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--time_length", type=int, default=5)
    parser.add_argument("--height", type=int, default=None)
    parser.add_argument("--width", type=int, default=None)

    parser.add_argument("--quantized_qwen", action="store_true")
    parser.add_argument("--text_token_padding", action="store_true")
    parser.add_argument("--expand_prompts", action="store_true")
    parser.add_argument("--max_samples", type=int, default=None)
    parser.add_argument("--use_prop_bucket", action="store_true",
                        help="For prop: Lucy-style resolution/frames from source video (bucket + target_frames)")
    parser.add_argument("--frame_mode", type=str, default="auto",
                        choices=["49", "81", "auto", "nearest"],
                        help="When use_prop_bucket: target frame count mode")
    parser.add_argument("--group_pixels", type=int, default=None,
                        help="Hunyuan-style: max bucket group (1-4) to use; limits resolution")

    return parser.parse_args()


def main():
    args = parse_args()
    rank, local_rank, world_size = _get_dist_info()

    run_inference_on_csv(
        conf_path=args.conf_path,
        dit_checkpoint=args.dit_checkpoint,
        csv_path=args.csv_path,
        output_dir=args.output_dir,
        data_root=args.data_root,
        fallback_task=args.task,
        num_steps=args.num_steps,
        guidance_weight=args.guidance_weight,
        seed=args.seed,
        time_length=args.time_length,
        height=args.height,
        width=args.width,
        quantized_qwen=args.quantized_qwen,
        text_token_padding=args.text_token_padding,
        expand_prompts=args.expand_prompts,
        max_samples=args.max_samples,
        guide_image_base_path=args.guide_image_base_path,
        use_prop_bucket=args.use_prop_bucket,
        frame_mode=args.frame_mode,
        group_pixels=args.group_pixels,
        rank=rank,
        local_rank=local_rank,
        world_size=world_size,
    )


if __name__ == "__main__":
    main()
