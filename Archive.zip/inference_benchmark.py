import os
import json
import time
import argparse

import torch
import torch.distributed as dist
from diffusers import Kandinsky5T2VPipeline
from diffusers.utils import export_to_video


def setup_distributed():
    """Initialize distributed process group for torchrun."""
    dist.init_process_group(backend="nccl")
    local_rank = int(os.environ["LOCAL_RANK"])
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    torch.cuda.set_device(local_rank)
    return rank, world_size, local_rank


def cleanup_distributed():
    """Destroy the distributed process group."""
    if dist.is_initialized():
        dist.destroy_process_group()


def partition_tasks(tasks, rank, world_size):
    """Evenly partition benchmark tasks across GPUs (round-robin)."""
    return [t for i, t in enumerate(tasks) if i % world_size == rank]


def main():
    parser = argparse.ArgumentParser(description="Kandinsky-5 T2V/T2I Benchmark Inference (multi-GPU)")
    parser.add_argument(
        "--benchmark", type=str, required=True,
        help="Path to the benchmark JSON file",
    )
    parser.add_argument(
        "--model_path", type=str,
        default="/scratch/dyvm6xra/dyvm6xrauser13/models/kandinskylab/Kandinsky-5.0-T2V-Lite-sft-5s-Diffusers",
        help="Path to the pretrained model",
    )
    parser.add_argument(
        "--output_dir", type=str, default="outputs_benchmark",
        help="Directory to save generated videos",
    )
    parser.add_argument(
        "--num_inference_steps", type=int, default=50,
        help="Number of denoising steps",
    )
    parser.add_argument(
        "--guidance_scale", type=float, default=5.0,
        help="Classifier-free guidance scale",
    )
    parser.add_argument(
        "--negative_prompt", type=str,
        default="Static, 2D cartoon, cartoon, 2d animation, paintings, images, worst quality, low quality, ugly, deformed, walking backwards",
        help="Negative prompt for generation",
    )
    parser.add_argument(
        "--fps", type=int, default=24,
        help="FPS for the output video",
    )
    parser.add_argument(
        "--quality", type=int, default=9,
        help="Video encoding quality (1-10)",
    )
    args = parser.parse_args()

    # ── Distributed setup ──────────────────────────────────────────────
    rank, world_size, local_rank = setup_distributed()
    device = torch.device(f"cuda:{local_rank}")

    if rank == 0:
        print(f"Running with {world_size} GPU(s)")

    # ── Load benchmark ─────────────────────────────────────────────────
    with open(args.benchmark, "r") as f:
        all_tasks = json.load(f)

    # Filter to supported task types (t2v and t2i)
    supported_tasks = {"t2v", "t2i"}
    all_tasks = [t for t in all_tasks if t.get("task") in supported_tasks]

    if rank == 0:
        t2v_count = sum(1 for t in all_tasks if t["task"] == "t2v")
        t2i_count = sum(1 for t in all_tasks if t["task"] == "t2i")
        print(f"Total tasks in benchmark: {len(all_tasks)} ({t2v_count} t2v, {t2i_count} t2i)")

    # Partition across GPUs
    my_tasks = partition_tasks(all_tasks, rank, world_size)
    print(f"[Rank {rank}] Assigned {len(my_tasks)} tasks")

    # ── Create output directory ────────────────────────────────────────
    os.makedirs(args.output_dir, exist_ok=True)

    # ── Load pipeline ──────────────────────────────────────────────────
    pipe = Kandinsky5T2VPipeline.from_pretrained(
        args.model_path,
        torch_dtype=torch.bfloat16,
    )
    pipe = pipe.to(device)

    if rank == 0:
        print("Pipeline loaded. Starting inference...")

    # ── Inference loop ─────────────────────────────────────────────────
    for idx, task in enumerate(my_tasks):
        task_type = task["task"]
        prompt = task["caption"]
        width = task["width"]
        height = task["height"]
        num_frames = task["frame_num"]
        save_name = task["save_name"]
        save_path = os.path.join(args.output_dir, save_name)

        print(f"[Rank {rank}] ({idx + 1}/{len(my_tasks)}) [{task_type}] Generating: {save_name}  "
              f"({width}x{height}, {num_frames} frames)")
        t0 = time.time()

        output = pipe(
            prompt=prompt,
            negative_prompt=args.negative_prompt,
            height=height,
            width=width,
            num_frames=num_frames,
            num_inference_steps=args.num_inference_steps,
            guidance_scale=args.guidance_scale,
        ).frames[0]

        if task_type == "t2i":
            # output is a list of PIL images; for t2i (1 frame) save the single image
            image = output[0] if isinstance(output, list) else output
            image.save(save_path)
        else:
            export_to_video(output, save_path, fps=args.fps, quality=args.quality)

        elapsed = time.time() - t0
        print(f"[Rank {rank}] ({idx + 1}/{len(my_tasks)}) [{task_type}] Saved: {save_path}  "
              f"({elapsed:.1f}s)")

    # ── Wait for all ranks, then report ────────────────────────────────
    dist.barrier()
    if rank == 0:
        print("All ranks finished. Benchmark complete.")

    cleanup_distributed()


if __name__ == "__main__":
    main()
