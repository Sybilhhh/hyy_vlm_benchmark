import torch
from torch import nn
from torch.utils.checkpoint import checkpoint as torch_checkpoint

from .nn import (
    TimeEmbeddings,
    TextEmbeddings,
    VisualEmbeddings,
    RoPE1D,
    RoPE3D,
    Modulation,
    MultiheadSelfAttentionEnc,
    MultiheadSelfAttentionDec,
    MultiheadCrossAttention,
    FeedForward,
    OutLayer,
    apply_scale_shift_norm,
    apply_gate_sum,
)
from .utils import fractal_flatten, fractal_unflatten


class TransformerEncoderBlock(nn.Module):
    def __init__(self, model_dim, time_dim, ff_dim, head_dim, attention_engine="auto", text_token_padding=False):
        super().__init__()
        self.text_modulation = Modulation(time_dim, model_dim, 6)

        self.self_attention_norm = nn.LayerNorm(model_dim, elementwise_affine=False)
        self.self_attention = MultiheadSelfAttentionEnc(model_dim, head_dim, attention_engine, text_token_padding)

        self.feed_forward_norm = nn.LayerNorm(model_dim, elementwise_affine=False)
        self.feed_forward = FeedForward(model_dim, ff_dim)

    def forward(self, x, time_embed, rope, attention_mask=None):
        self_attn_params, ff_params = torch.chunk(self.text_modulation(time_embed), 2, dim=-1)
        shift, scale, gate = torch.chunk(self_attn_params, 3, dim=-1)
        out = apply_scale_shift_norm(self.self_attention_norm, x, scale, shift)
        out = self.self_attention(out, rope, attention_mask)
        x = apply_gate_sum(x, out, gate)

        shift, scale, gate = torch.chunk(ff_params, 3, dim=-1)
        out = apply_scale_shift_norm(self.feed_forward_norm, x, scale, shift)
        out = self.feed_forward(out)
        x = apply_gate_sum(x, out, gate)
        return x


class TransformerDecoderBlock(nn.Module):
    def __init__(self, model_dim, time_dim, ff_dim, head_dim, attention_engine="auto", text_token_padding=False):
        super().__init__()
        self.visual_modulation = Modulation(time_dim, model_dim, 9)

        self.self_attention_norm = nn.LayerNorm(model_dim, elementwise_affine=False)
        self.self_attention = MultiheadSelfAttentionDec(model_dim, head_dim, attention_engine)

        self.cross_attention_norm = nn.LayerNorm(model_dim, elementwise_affine=False)
        self.cross_attention = MultiheadCrossAttention(model_dim, head_dim, attention_engine, text_token_padding)

        self.feed_forward_norm = nn.LayerNorm(model_dim, elementwise_affine=False)
        self.feed_forward = FeedForward(model_dim, ff_dim)

    def forward(self, visual_embed, text_embed, time_embed, rope, sparse_params, attention_mask=None):
        self_attn_params, cross_attn_params, ff_params = torch.chunk(
            self.visual_modulation(time_embed), 3, dim=-1
        )
        shift, scale, gate = torch.chunk(self_attn_params, 3, dim=-1)
        visual_out = apply_scale_shift_norm(self.self_attention_norm, visual_embed, scale, shift)
        visual_out = self.self_attention(visual_out, rope, sparse_params)
        visual_embed = apply_gate_sum(visual_embed, visual_out, gate)

        shift, scale, gate = torch.chunk(cross_attn_params, 3, dim=-1)
        visual_out = apply_scale_shift_norm(self.cross_attention_norm, visual_embed, scale, shift)
        visual_out = self.cross_attention(visual_out, text_embed, attention_mask)
        visual_embed = apply_gate_sum(visual_embed, visual_out, gate)

        shift, scale, gate = torch.chunk(ff_params, 3, dim=-1)
        visual_out = apply_scale_shift_norm(self.feed_forward_norm, visual_embed, scale, shift)
        visual_out = self.feed_forward(visual_out)
        visual_embed = apply_gate_sum(visual_embed, visual_out, gate)
        return visual_embed


class DiffusionTransformer3DTokenConcat(nn.Module):
    """DiT variant using token-wise concatenation for visual conditioning.

    Noise path: (T, H, W, 17) = [noisy_latent(16) | denoise_mask(1)]
        - denoise_mask: 1 = denoise this frame, 0 = frame is given/clean
        - VisualEmbeddings: Linear(17 * patch_prod, model_dim)

    Cond path: (K, H, W, 16) = source latent for conditioned frames only
        - Variable length: 0 tokens for t2v/t2i, N tokens for ti2i/tv2v,
          K < N tokens for future I2V/propagation tasks
        - CondEmbeddings: Linear(16 * patch_prod, model_dim)
        - Presence/absence of cond tokens is the conditioning signal

    The two sets of tokens are concatenated along the sequence dimension.
    Only the noise-half tokens are decoded through OutLayer.
    """

    def __init__(
        self,
        in_visual_dim=16,
        in_text_dim=3584,
        in_text_dim2=768,
        time_dim=512,
        out_visual_dim=16,
        patch_size=(1, 2, 2),
        model_dim=1792,
        ff_dim=7168,
        num_text_blocks=2,
        num_visual_blocks=32,
        axes_dims=(16, 24, 24),
        attention_engine="auto",
        text_token_padding=False,
        # Ignored -- kept for config compat with base DiT
        visual_cond=False,
        instruct_type=None,
    ):
        super().__init__()
        self.instruct_type = "token_concat"
        self.visual_cond = False
        head_dim = sum(axes_dims)
        self.in_visual_dim = in_visual_dim
        self.model_dim = model_dim
        self.patch_size = patch_size
        self.text_token_padding = text_token_padding

        self.time_embeddings = TimeEmbeddings(model_dim, time_dim)
        self.text_embeddings = TextEmbeddings(in_text_dim, model_dim)
        self.pooled_text_embeddings = TextEmbeddings(in_text_dim2, time_dim)

        # Noise path: 17ch = 16ch latent + 1ch denoise_mask
        self.visual_embeddings = VisualEmbeddings(in_visual_dim + 1, model_dim, patch_size)
        # Cond path: 16ch = pure latent (no mask -- presence of tokens is the signal)
        self.cond_embeddings = VisualEmbeddings(in_visual_dim, model_dim, patch_size)

        self.text_rope_embeddings = RoPE1D(head_dim)
        self.text_transformer_blocks = nn.ModuleList(
            [
                TransformerEncoderBlock(model_dim, time_dim, ff_dim, head_dim, attention_engine, text_token_padding)
                for _ in range(num_text_blocks)
            ]
        )

        self.visual_rope_embeddings = RoPE3D(axes_dims)
        self.visual_transformer_blocks = nn.ModuleList(
            [
                TransformerDecoderBlock(model_dim, time_dim, ff_dim, head_dim, attention_engine, text_token_padding)
                for _ in range(num_visual_blocks)
            ]
        )

        self.out_layer = OutLayer(model_dim, time_dim, out_visual_dim, patch_size)
        self._gradient_checkpointing = False

    def gradient_checkpointing_enable(self):
        self._gradient_checkpointing = True

    def gradient_checkpointing_disable(self):
        self._gradient_checkpointing = False

    def forward(
        self,
        x,
        text_embed,
        pooled_text_embed,
        time,
        visual_rope_pos,
        text_rope_pos,
        scale_factor=(1.0, 1.0, 1.0),
        sparse_params=None,
        attention_mask=None,
        cond=None,
        cond_rope_pos=None,
    ):
        """
        Args:
            x: noisy latent + denoise_mask, (T, H, W, 17)
            text_embed: Qwen text embeddings
            pooled_text_embed: CLIP pooled embedding
            time: diffusion timestep
            visual_rope_pos: [t_pos, h_pos, w_pos] for RoPE on noise tokens
            text_rope_pos: text token positions for RoPE
            scale_factor: RoPE scale factors
            sparse_params: ignored (kept for API compat)
            attention_mask: text attention mask
            cond: conditioning latent, (K, H, W, 16) or None
                  K=0 means no conditioning (t2v/t2i).
                  K=T means full conditioning (ti2i/tv2v).
                  K<T for future partial conditioning (I2V).
            cond_rope_pos: [t_pos, h_pos, w_pos] for RoPE on cond tokens,
                           or None to reuse visual_rope_pos

        Returns:
            velocity prediction, (T, H, W, 16)
        """
        text_embed = self.text_embeddings(text_embed)
        time_embed = self.time_embeddings(time)
        time_embed = time_embed + self.pooled_text_embeddings(pooled_text_embed)
        text_rope = self.text_rope_embeddings(text_rope_pos)

        noise_embed = self.visual_embeddings(x)
        noise_shape = noise_embed.shape[:-1]  # (T', H', W')

        visual_rope_single = self.visual_rope_embeddings(noise_shape, visual_rope_pos, scale_factor)

        for text_transformer_block in self.text_transformer_blocks:
            text_embed = text_transformer_block(text_embed, time_embed, text_rope, attention_mask)

        noise_flat, rope_flat = fractal_flatten(
            noise_embed, visual_rope_single, noise_shape, block_mask=False,
        )
        num_noise_tokens = noise_flat.shape[0]

        has_cond = cond is not None and cond.shape[0] > 0
        if has_cond:
            cond_embed = self.cond_embeddings(cond)
            cond_shape = cond_embed.shape[:-1]

            if cond_rope_pos is not None:
                cond_rope_single = self.visual_rope_embeddings(cond_shape, cond_rope_pos, scale_factor)
            else:
                cond_rope_single = self.visual_rope_embeddings(cond_shape, visual_rope_pos, scale_factor)

            cond_flat, cond_rope_flat = fractal_flatten(
                cond_embed, cond_rope_single, cond_shape, block_mask=False,
            )
            visual_embed = torch.cat([noise_flat, cond_flat], dim=0).unsqueeze(0)
            visual_rope = torch.cat([rope_flat, cond_rope_flat], dim=0)
        else:
            visual_embed = noise_flat.unsqueeze(0)
            visual_rope = rope_flat

        for visual_transformer_block in self.visual_transformer_blocks:
            if self._gradient_checkpointing and self.training:
                visual_embed = torch_checkpoint(
                    visual_transformer_block, visual_embed, text_embed, time_embed,
                    visual_rope, None, attention_mask,
                    use_reentrant=False,
                )
            else:
                visual_embed = visual_transformer_block(
                    visual_embed, text_embed, time_embed,
                    visual_rope, None, attention_mask,
                )

        noise_out = visual_embed[:, :num_noise_tokens]

        noise_out = fractal_unflatten(noise_out, noise_shape, block_mask=False)
        x = self.out_layer(noise_out, text_embed, time_embed)
        return x


def get_dit_token_concat(conf, text_token_padding=False):
    dit = DiffusionTransformer3DTokenConcat(**conf, text_token_padding=text_token_padding)
    return dit
