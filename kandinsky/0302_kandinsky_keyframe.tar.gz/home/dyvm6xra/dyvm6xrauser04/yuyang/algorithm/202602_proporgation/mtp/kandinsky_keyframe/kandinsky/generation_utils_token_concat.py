import os
os.environ["TOKENIZERS_PARALLELISM"] = "False"

import torch
from torch.distributed import all_gather
from tqdm import tqdm

from .generation_utils import (
    encode_video,
    resize_video,
    get_task_mask,
)


def get_sparse_params(conf, noise_img, device):
    # Token-concat doubles the visual sequence length, making nabla sparse
    # attention masks (sized for a single grid) incompatible. Always use
    # dense attention for the token-concat DiT.
    return None


def prepare_cond_input_token_concat(task_type, cond_latent, noise_img, task_mask):
    """Build separate noise and conditioning tensors for token-concat DiT.

    Returns:
        noise_with_mask: (T, H, W, 17) -- [noisy_latent(16) | denoise_mask(1)]
        cond_latent_out:  (K, H, W, 16) or None
            K = number of conditioned frames (0 for t2v/t2i, T for ti2i/tv2v).
            Presence/absence of cond tokens is the conditioning signal; no mask needed.
    """
    T, H, W, C = noise_img.shape

    denoise_mask_channel = torch.ones(T, H, W, 1, device=noise_img.device, dtype=noise_img.dtype)
    noise_with_mask = torch.cat([noise_img, denoise_mask_channel], dim=-1)

    if cond_latent is not None:
        cond_latent_out = cond_latent.to(device=noise_img.device, dtype=noise_img.dtype)
    else:
        cond_latent_out = None

    return noise_with_mask, cond_latent_out


@torch.no_grad()
def get_velocity_token_concat(
    dit,
    noise_img,
    cond_input,
    t,
    text_embeds,
    null_text_embeds,
    visual_rope_pos,
    text_rope_pos,
    null_text_rope_pos,
    guidance_weight,
    conf,
    sparse_params=None,
    attention_mask=None,
    null_attention_mask=None,
):
    with torch._dynamo.utils.disable_cache_limit():
        pred_velocity = dit(
            noise_img,
            text_embeds["text_embeds"],
            text_embeds["pooled_embed"],
            t * 1000,
            visual_rope_pos,
            text_rope_pos,
            scale_factor=conf.metrics.scale_factor,
            attention_mask=attention_mask,
            cond=cond_input,
        )
        if abs(guidance_weight - 1.0) > 1e-6:
            uncond_pred_velocity = dit(
                noise_img,
                null_text_embeds["text_embeds"],
                null_text_embeds["pooled_embed"],
                t * 1000,
                visual_rope_pos,
                null_text_rope_pos,
                scale_factor=conf.metrics.scale_factor,
                attention_mask=null_attention_mask,
                cond=cond_input,
            )
            pred_velocity = uncond_pred_velocity + guidance_weight * (
                pred_velocity - uncond_pred_velocity
            )
    return pred_velocity


@torch.no_grad()
def generate_token_concat(
    model,
    device,
    noise_img,
    cond_input,
    num_steps,
    text_embeds,
    null_text_embeds,
    visual_rope_pos,
    text_rope_pos,
    null_text_rope_pos,
    guidance_weight,
    scheduler_scale,
    conf,
    progress=False,
    seed=6554,
    tp_mesh=None,
    attention_mask=None,
    null_attention_mask=None,
):
    """Denoising loop for token-concat DiT.

    noise_img (T,H,W,17) = [noisy_latent(16) | denoise_mask(1)].
    cond_input (K,H,W,16) or None -- conditioning latent for K frames.
    Only the first 16 channels of noise_img are updated with Euler steps;
    the denoise_mask channel is fixed throughout.
    """
    sparse_params = get_sparse_params(conf, noise_img, device)
    timesteps = torch.linspace(1, 0, num_steps + 1, device=device)
    timesteps = scheduler_scale * timesteps / (1 + (scheduler_scale - 1) * timesteps)

    for timestep, timestep_diff in tqdm(list(zip(timesteps[:-1], torch.diff(timesteps)))):
        time = timestep.unsqueeze(0)
        pred_velocity = get_velocity_token_concat(
            model,
            noise_img,
            cond_input,
            time,
            text_embeds,
            null_text_embeds,
            visual_rope_pos,
            text_rope_pos,
            null_text_rope_pos,
            guidance_weight,
            conf,
            sparse_params=sparse_params,
            attention_mask=attention_mask,
            null_attention_mask=null_attention_mask,
        )
        noise_img = torch.cat([
            noise_img[..., :16] + timestep_diff * pred_velocity,
            noise_img[..., 16:],
        ], dim=-1)

    return noise_img


def generate_unified_sample_token_concat(
    shape,
    caption,
    dit,
    vae,
    conf,
    text_embedder,
    task_type="t2v",
    cond_latent=None,
    num_steps=50,
    guidance_weight=5.0,
    scheduler_scale=10.0,
    negative_caption="",
    seed=6554,
    device="cuda",
    vae_device="cuda",
    text_embedder_device="cuda",
    progress=True,
    offload=False,
    images_for_text_encoder=None,
    tp_mesh=None,
):
    """Unified sampling for token-concat DiT (t2v, t2i, ti2i, tv2v).

    Noise path: (T,H,W,17) = [noisy_latent(16) | denoise_mask(1)]
    Cond path:  (K,H,W,16) or None -- source latent for conditioned frames.
        K=0 / None for t2v/t2i, K=T for ti2i/tv2v.
    The DiT concatenates them along the token/sequence dimension internally.
    """
    bs, duration, height, width, dim = shape

    g = torch.Generator(device="cuda")
    g.manual_seed(seed)
    noise_img = torch.randn(
        bs * duration, height, width, dim,
        device=device, generator=g, dtype=torch.bfloat16,
    )

    if task_type == "ti2i" and images_for_text_encoder is not None:
        type_of_content = "image_edit"
    elif duration == 1:
        type_of_content = "image"
    else:
        type_of_content = "video"

    task_mask = get_task_mask(task_type, duration)
    noise_img, cond_input = prepare_cond_input_token_concat(
        task_type, cond_latent, noise_img, task_mask,
    )

    with torch.no_grad():
        bs_text_embed, text_cu_seqlens, attention_mask = text_embedder.encode(
            [caption], type_of_content=type_of_content, images=images_for_text_encoder,
        )
        bs_null_text_embed, null_text_cu_seqlens, null_attention_mask = text_embedder.encode(
            [negative_caption], type_of_content=type_of_content, images=images_for_text_encoder,
        )

    if offload:
        text_embedder = text_embedder.to("cpu")

    for key in bs_text_embed:
        bs_text_embed[key] = bs_text_embed[key].to(device=device, dtype=torch.bfloat16)
        bs_null_text_embed[key] = bs_null_text_embed[key].to(device=device, dtype=torch.bfloat16)
    text_cu_seqlens = text_cu_seqlens.to(device=device)[-1].item()
    null_text_cu_seqlens = null_text_cu_seqlens.to(device=device)[-1].item()

    visual_rope_pos = [
        torch.arange(duration),
        torch.arange(shape[-3] // conf.model.dit_params.patch_size[1]),
        torch.arange(shape[-2] // conf.model.dit_params.patch_size[2]),
    ]
    text_rope_pos = torch.arange(text_cu_seqlens)
    null_text_rope_pos = torch.arange(null_text_cu_seqlens)

    if offload:
        dit.to(device, non_blocking=True)

    with torch.no_grad():
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            latent_visual = generate_token_concat(
                dit,
                device,
                noise_img,
                cond_input,
                num_steps,
                bs_text_embed,
                bs_null_text_embed,
                visual_rope_pos,
                text_rope_pos,
                null_text_rope_pos,
                guidance_weight,
                scheduler_scale,
                conf,
                seed=seed,
                progress=progress,
                tp_mesh=tp_mesh,
                attention_mask=attention_mask,
                null_attention_mask=null_attention_mask,
            )

    latent_visual = latent_visual[..., :16]

    if tp_mesh:
        tensor_list = [
            torch.zeros_like(latent_visual, device=latent_visual.device)
            for _ in range(tp_mesh["tensor_parallel"].size())
        ]
        all_gather(
            tensor_list,
            latent_visual.contiguous(),
            group=tp_mesh.get_group(mesh_dim="tensor_parallel"),
        )
        latent_visual = torch.cat(tensor_list, dim=1)

    if offload:
        dit = dit.to("cpu", non_blocking=True)
    torch.cuda.empty_cache()

    if offload:
        vae = vae.to(vae_device, non_blocking=True)

    with torch.no_grad():
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            images = latent_visual.reshape(
                bs, -1,
                latent_visual.shape[-3],
                latent_visual.shape[-2],
                latent_visual.shape[-1],
            )
            images = images.to(device=vae_device)
            images = (images / vae.config.scaling_factor).permute(0, 4, 1, 2, 3)
            images = vae.decode(images).sample
            images = ((images.clamp(-1.0, 1.0) + 1.0) * 127.5).to(torch.uint8)

    if offload:
        vae = vae.to("cpu", non_blocking=True)
    torch.cuda.empty_cache()

    return images
