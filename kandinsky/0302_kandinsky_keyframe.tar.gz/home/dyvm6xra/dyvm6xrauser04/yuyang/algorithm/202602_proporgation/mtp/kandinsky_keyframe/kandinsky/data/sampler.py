"""Multi-resolution multi-task batch samplers for Kandinsky-5 training.

Ensures each batch contains only samples from the same (task, bucket) pair,
which is required for batched training with variable resolutions and frame
counts.

Bucket keys are strings produced by the dataset:
- ``'H_W'``     (e.g. ``'512_768'``)    when ``frame_nums`` column is absent
- ``'H_W_F'``   (e.g. ``'512_768_81'``) when ``frame_nums`` column is present

The samplers are agnostic to the bucket format — they simply group by whatever
string key the dataset provides.

Adapted from HunyuanVideo 1.5 sampler.py.
"""

import os
from typing import Iterator, List, Optional

import torch
import torch.distributed as dist
from torch.utils.data import Sampler


class MultiResMultiTaskSampler(Sampler):
    """Single-process sampler that groups samples by (task, bucket).

    The bucket string may encode only spatial resolution (``'H_W'``) or
    spatial resolution plus frame count (``'H_W_F'``), depending on whether
    the CSV contained a ``frame_nums`` column.
    """

    TASK_TO_BATCH_SIZE = {
        "tv2v": 1,
        "ti2i": 4,
        "t2v": 1,
        "t2i": 4,
        "recon_v": 1,
        "recon_i": 4,
        "prop": 1,
        "i2v": 1,
        "keyframe": 1,
    }

    def __init__(
        self,
        dataset,
        video_batch_size: int = 1,
        image_batch_size: int = 4,
        gen_video_batch_size: int = 1,
        gen_image_batch_size: int = 4,
        recon_video_batch_size: Optional[int] = None,
        recon_image_batch_size: Optional[int] = None,
        shuffle: bool = True,
        seed: int = 42,
        drop_last: bool = True,
    ):
        self.dataset = dataset
        self.shuffle = shuffle
        self.seed = seed
        self.drop_last = drop_last
        self.epoch = 0

        self.task_bucket_to_indices = dataset.task_bucket_to_indices
        self.task_buckets = dataset.task_buckets

        self.task_to_batch_size = {
            # Video edit / propagation / i2v / keyframe tasks share the video batch size
            "tv2v": video_batch_size,
            "prop": video_batch_size,
            "i2v": video_batch_size,
            "keyframe": video_batch_size,
            # Image edit
            "ti2i": image_batch_size,
            # Pure generation
            "t2v": gen_video_batch_size,
            "t2i": gen_image_batch_size,
            # Recon tasks default to generation batch sizes unless overridden
            "recon_v": recon_video_batch_size if recon_video_batch_size is not None else gen_video_batch_size,
            "recon_i": recon_image_batch_size if recon_image_batch_size is not None else gen_image_batch_size,
        }

        self.task_bucket_batches = {}
        total_batches = 0
        for task in sorted(self.task_buckets.keys()):
            bs = self.task_to_batch_size.get(task, video_batch_size)
            for bucket in sorted(self.task_buckets[task]):
                key = (task, bucket)
                indices = self.task_bucket_to_indices[key]
                n = len(indices) // bs
                if not self.drop_last and len(indices) % bs > 0:
                    n += 1
                self.task_bucket_batches[key] = n
                total_batches += n
        self.total_batches = total_batches

    def _create_batches(self, indices, batch_size, generator):
        indices = list(indices)
        if self.shuffle:
            perm = torch.randperm(len(indices), generator=generator).tolist()
            indices = [indices[i] for i in perm]
        batches = []
        for i in range(0, len(indices), batch_size):
            batch = indices[i : i + batch_size]
            if not self.drop_last or len(batch) == batch_size:
                batches.append([int(x) for x in batch])
        return batches

    def __iter__(self) -> Iterator[List[int]]:
        g = torch.Generator()
        g.manual_seed(self.seed + self.epoch)

        all_batches = []
        for task in sorted(self.task_buckets.keys()):
            bs = self.task_to_batch_size.get(task, 1)
            for bucket in sorted(self.task_buckets[task]):
                indices = self.task_bucket_to_indices[(task, bucket)]
                if len(indices) > 0:
                    all_batches.extend(self._create_batches(indices, bs, g))

        if self.shuffle:
            perm = torch.randperm(len(all_batches), generator=g).tolist()
            all_batches = [all_batches[i] for i in perm]

        return iter(all_batches)

    def __len__(self) -> int:
        return self.total_batches

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch


class MultiResMultiTaskSamplerDistributed(Sampler):
    """Distributed sampler that groups samples by (task, bucket).

    The bucket string may encode only spatial resolution (``'H_W'``) or
    spatial resolution plus frame count (``'H_W_F'``), depending on whether
    the CSV contained a ``frame_nums`` column.  When frame counts are part of
    the bucket, every sample in a batch is guaranteed to share the same T
    dimension as well as the same H/W.

    Within each (task, bucket) group the sample indices are pooled across all
    ranks and then split so that every rank in the same global step processes
    a sample from the **same** (task, bucket).  This guarantees roughly equal
    VRAM usage across GPUs and makes the DDP allreduce meaningful.

    Sharding is done internally (via self.rank / self.num_replicas), so the
    DataLoader that uses this sampler must NOT be wrapped by Accelerate's own
    distributed sharding.  Pass ``dispatch_batches=False`` and
    ``split_batches=False`` (or skip ``accelerator.prepare`` for the
    dataloader).
    """

    TASK_TO_BATCH_SIZE = {
        "tv2v": 1,
        "ti2i": 4,
        "t2v": 1,
        "t2i": 4,
        "recon_v": 1,
        "recon_i": 4,
        "prop": 1,
        "i2v": 1,
        "keyframe": 1,
    }

    def __init__(
        self,
        dataset,
        video_batch_size: int = 1,
        image_batch_size: int = 4,
        gen_video_batch_size: int = 1,
        gen_image_batch_size: int = 4,
        recon_video_batch_size: Optional[int] = None,
        recon_image_batch_size: Optional[int] = None,
        shuffle: bool = True,
        seed: int = 42,
        drop_last: bool = True,
        num_replicas: Optional[int] = None,
        rank: Optional[int] = None,
    ):
        if num_replicas is None:
            if dist.is_available() and dist.is_initialized():
                self.num_replicas = dist.get_world_size()
            else:
                ws = os.environ.get("WORLD_SIZE")
                self.num_replicas = int(ws) if ws else 1
        else:
            self.num_replicas = num_replicas

        if rank is None:
            if dist.is_available() and dist.is_initialized():
                self.rank = dist.get_rank()
            else:
                r = os.environ.get("RANK")
                self.rank = int(r) if r else 0
        else:
            self.rank = rank

        self.dataset = dataset
        self.shuffle = shuffle
        self.seed = seed
        self.drop_last = drop_last
        self.epoch = 0

        self.task_bucket_to_indices = dataset.task_bucket_to_indices
        self.task_buckets = dataset.task_buckets

        self.task_to_batch_size = {
            # Video edit / propagation / i2v / keyframe tasks share the video batch size
            "tv2v": video_batch_size,
            "prop": video_batch_size,
            "i2v": video_batch_size,
            "keyframe": video_batch_size,
            # Image edit
            "ti2i": image_batch_size,
            # Pure generation
            "t2v": gen_video_batch_size,
            "t2i": gen_image_batch_size,
            # Recon tasks default to generation batch sizes unless overridden
            "recon_v": recon_video_batch_size if recon_video_batch_size is not None else gen_video_batch_size,
            "recon_i": recon_image_batch_size if recon_image_batch_size is not None else gen_image_batch_size,
        }

        self.task_bucket_batches = {}
        global_total = 0
        for task in sorted(self.task_buckets.keys()):
            bs = self.task_to_batch_size.get(task, video_batch_size)
            for bucket in sorted(self.task_buckets[task]):
                key = (task, bucket)
                indices = self.task_bucket_to_indices[key]
                per_rank = bs * self.num_replicas
                n = len(indices) // per_rank
                if not self.drop_last and len(indices) % per_rank > 0:
                    n += 1
                self.task_bucket_batches[key] = n
                global_total += n

        self.num_batches_per_replica = global_total

        if self.rank == 0:
            print(
                f"MultiResMultiTaskSamplerDistributed: "
                f"{self.num_batches_per_replica} steps/epoch, "
                f"{self.num_replicas} replicas"
            )
            for task in sorted(self.task_buckets.keys()):
                for bucket in sorted(self.task_buckets[task]):
                    key = (task, bucket)
                    n_samples = len(self.task_bucket_to_indices[key])
                    n_batches = self.task_bucket_batches[key]
                    print(
                        f"  {task} bucket={bucket}: "
                        f"{n_samples} samples, {n_batches} batches/rank"
                    )

    def _create_rank_batches(self, indices, batch_size, generator):
        """Split *indices* into per-rank batches of size *batch_size*.

        Indices are shuffled (if enabled), then grouped into chunks of
        ``batch_size * num_replicas``.  Each chunk is split across ranks so
        that all ranks at the same global step get samples from the same
        (task, bucket).
        """
        indices = list(indices)
        if self.shuffle:
            perm = torch.randperm(len(indices), generator=generator).tolist()
            indices = [indices[i] for i in perm]

        per_rank = batch_size * self.num_replicas
        batches = []
        for i in range(0, len(indices), per_rank):
            chunk = indices[i : i + per_rank]
            if len(chunk) < per_rank:
                if self.drop_last:
                    continue
                chunk = chunk + chunk[: per_rank - len(chunk)]
            rank_start = self.rank * batch_size
            rank_batch = chunk[rank_start : rank_start + batch_size]
            batches.append([int(x) for x in rank_batch])
        return batches

    def __iter__(self) -> Iterator[List[int]]:
        g = torch.Generator()
        g.manual_seed(self.seed + self.epoch)

        all_batches = []
        for task in sorted(self.task_buckets.keys()):
            bs = self.task_to_batch_size.get(task, 1)
            for bucket in sorted(self.task_buckets[task]):
                indices = self.task_bucket_to_indices[(task, bucket)]
                if len(indices) > 0:
                    all_batches.extend(
                        self._create_rank_batches(indices, bs, g)
                    )

        if self.shuffle:
            perm = torch.randperm(len(all_batches), generator=g).tolist()
            all_batches = [all_batches[i] for i in perm]

        return iter(all_batches)

    def __len__(self) -> int:
        return self.num_batches_per_replica

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch
