"""Multi-resolution multi-task dataset for Kandinsky-5 unified training.

Supports task types: t2v, t2i, ti2i, tv2v.
Loads raw videos/images from CSV annotations; feature extraction happens
in the training loop (online mode).

Adapted from HunyuanVideo 1.5 MultiResVideoEditDatasetOnline, with:
- SigLIP / ByT5 fields removed (Kandinsky uses Qwen2.5-VL multimodal)
- Spatial downsampling adjusted to 8x (Kandinsky) vs 16x (HunyuanVideo)
- Resolution buckets adjusted for Kandinsky (512/1024)
"""

import os
import random
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import decord
import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms


def is_main_process():
    if not torch.distributed.is_available():
        return True
    if not torch.distributed.is_initialized():
        return True
    return torch.distributed.get_rank() == 0


def parse_bucket(bucket_str):
    """Parse bucket string to (height, width) and optional frame count.

    Accepts ``'H_W'`` (e.g. ``'512_768'``) or ``'H_W_F'`` (e.g. ``'512_768_81'``).
    Returns ``(height, width)`` — the frame count, if present, is stored
    separately in the data dict and not returned here.
    """
    try:
        parts = bucket_str.split("_")
        if len(parts) == 2:
            height, width = int(parts[0]), int(parts[1])
        elif len(parts) == 3:
            height, width = int(parts[0]), int(parts[1])
        else:
            raise ValueError(f"Invalid bucket format: {bucket_str}")
        assert height % 8 == 0, f"Height {height} must be divisible by 8"
        assert width % 8 == 0, f"Width {width} must be divisible by 8"
        return (height, width)
    except Exception as e:
        print(f"Error parsing bucket {bucket_str}: {e}")
        return None


def make_bucket_key(hw_bucket: str, frame_nums) -> str:
    """Build the composite bucket key used for sampler grouping.

    If *frame_nums* is a valid integer > 1, returns ``'H_W_F'``
    (e.g. ``'512_768_81'``).  Otherwise returns the plain HW bucket.
    """
    if frame_nums is not None and not pd.isna(frame_nums) and int(frame_nums) > 1:
        return f"{hw_bucket}_{int(frame_nums)}"
    return hw_bucket


def is_video_file(file_path):
    if not file_path:
        return False
    video_extensions = {
        ".mp4", ".avi", ".mov", ".mkv", ".flv", ".wmv", ".webm", ".m4v",
    }
    _, ext = os.path.splitext(file_path.lower())
    return ext in video_extensions


def load_video_frames(video_path, target_size=(512, 768), max_frames=31):
    """Load video frames, center-crop and resize.

    Returns:
        frames: (1, C, T, H, W) float tensor in [-1, 1]
        first_frame_numpy: (H, W, C) uint8 numpy
    """
    try:
        vr = decord.VideoReader(video_path, ctx=decord.cpu(0))
        total_frames = len(vr)
        orig_h, orig_w = vr[0].shape[:2]

        if total_frames >= max_frames:
            frame_indices = list(range(max_frames))
        else:
            frame_indices = list(range(total_frames)) + [total_frames - 1] * (max_frames - total_frames)

        frames = vr.get_batch(frame_indices).asnumpy()  # (T, H, W, C)
        target_h, target_w = target_size

        orig_aspect = orig_w / orig_h
        target_aspect = target_w / target_h
        if orig_aspect > target_aspect:
            crop_w = int(orig_h * target_aspect)
            crop_h = orig_h
            start_w = (orig_w - crop_w) // 2
            start_h = 0
        else:
            crop_h = int(orig_w / target_aspect)
            crop_w = orig_w
            start_h = (orig_h - crop_h) // 2
            start_w = 0

        frames = frames[:, start_h : start_h + crop_h, start_w : start_w + crop_w, :]
        frames = torch.from_numpy(frames).float()  # (T, H, W, C)
        frames = frames.permute(0, 3, 1, 2)  # (T, C, H, W)

        resize_transform = transforms.Resize((target_h, target_w), antialias=True)
        frames = resize_transform(frames)

        first_frame_numpy = (
            frames[0].permute(1, 2, 0).clamp(0, 255).cpu().numpy().astype(np.uint8)
        )

        frames = frames / 127.5 - 1.0
        frames = frames.unsqueeze(0).permute(0, 2, 1, 3, 4)  # (1, C, T, H, W)

        return frames, first_frame_numpy
    except Exception as e:
        print(f"Error loading video {video_path}: {e}")
        return None, None


def load_video_key_frames(video_path, max_frames=31, target_size=(512, 768)):
    """Load first/mid/last key frames from a video.

    Returns:
        key_frames: (1, C, 3, H, W) float tensor in [-1, 1]
        key_frames_numpy: (3, H, W, C) uint8 numpy
    """
    try:
        vr = decord.VideoReader(video_path, ctx=decord.cpu(0))
        total_frames = min(max_frames, len(vr))
        assert len(vr) >= max_frames, (
            f"Video {video_path} has {len(vr)} frames < {max_frames}"
        )

        orig_h, orig_w = vr[0].shape[:2]
        target_h, target_w = target_size

        indices = [0, total_frames // 2, total_frames - 1]
        raw_frames = vr.get_batch(indices).asnumpy()  # (3, H, W, C)

        orig_aspect = orig_w / orig_h
        target_aspect = target_w / target_h
        if orig_aspect > target_aspect:
            crop_w = int(orig_h * target_aspect)
            crop_h = orig_h
            start_w = (orig_w - crop_w) // 2
            start_h = 0
        else:
            crop_h = int(orig_w / target_aspect)
            crop_w = orig_w
            start_h = (orig_h - crop_h) // 2
            start_w = 0

        raw_frames = raw_frames[
            :, start_h : start_h + crop_h, start_w : start_w + crop_w, :
        ]

        frames_t = torch.from_numpy(raw_frames).float().permute(0, 3, 1, 2)
        resize_transform = transforms.Resize((target_h, target_w), antialias=True)
        frames_t = resize_transform(frames_t)

        key_frames_numpy = (
            frames_t.permute(0, 2, 3, 1).clamp(0, 255).cpu().numpy().astype(np.uint8)
        )

        frames_t = frames_t / 127.5 - 1.0
        key_frames = frames_t.unsqueeze(0).permute(0, 2, 1, 3, 4)  # (1, C, 3, H, W)

        return key_frames, key_frames_numpy
    except Exception as e:
        print(f"Error loading key frames {video_path}: {e}")
        return None, None


def load_image(image_path, target_size=(1024, 1024)):
    """Load and resize an image.

    Returns:
        image_tensor: (1, C, 1, H, W) float tensor in [-1, 1]
        image_numpy: (H, W, C) uint8 numpy
    """
    try:
        img = Image.open(image_path).convert("RGB")
        target_h, target_w = target_size
        img = img.resize((target_w, target_h), Image.LANCZOS)
        img_np = np.array(img)
        img_t = torch.from_numpy(img_np).float().permute(2, 0, 1)  # (C, H, W)
        img_t_normalized = img_t / 127.5 - 1.0
        img_t_normalized = img_t_normalized.unsqueeze(0).unsqueeze(2)  # (1, C, 1, H, W)
        return img_t_normalized, img_np
    except Exception as e:
        print(f"Error loading image {image_path}: {e}")
        return None, None


class MultiResDataset(Dataset):
    """Multi-resolution multi-task dataset for Kandinsky-5 unified training.

    CSV format for tv2v:
        video1_path, video2_path, editing_instruction, video2_caption,
        bucket, frames, task_type, data_type

    CSV format for ti2i:
        img1_path, img2_path, editing_instruction, img2_caption,
        bucket, task_type, data_type

    CSV format for t2v:
        video_path, caption, bucket, frames, task_type, data_type

    CSV format for t2i:
        img_path, caption, bucket, task_type, data_type
    """

    RECONSTRUCTION_INSTRUCTIONS = [
        "Keep the visual information unchanged.",
        "Preserve the original content exactly as it is.",
        "Do not modify anything in this visual.",
        "Return the input without any changes.",
        "Maintain the visual content identically.",
        "Keep everything the same, no edits needed.",
        "Leave the visual unchanged.",
        "Output the same visual as the input.",
        "No transformation required, keep as is.",
        "Reproduce the input faithfully.",
        "Copy the visual content without alterations.",
        "Pass through the input without editing.",
    ]

    def __init__(
        self,
        csv_path: Union[str, List[str]],
        data_root: Union[str, List[str], None] = None,
        max_frames: int = 31,
        reconstruction_ratio: float = 0.0,
        **kwargs,
    ):
        self.max_frames = max_frames
        self.reconstruction_ratio = reconstruction_ratio

        if isinstance(csv_path, str):
            csv_path = [csv_path]
        if data_root is None or isinstance(data_root, str):
            data_root = [data_root] if data_root is not None else [None]
        if len(data_root) == 1:
            data_root = data_root * len(csv_path)
        assert len(csv_path) == len(data_root)

        self.data_list = []
        self.video_data_list = []
        self.image_data_list = []
        self.gen_video_data_list = []
        self.gen_image_data_list = []

        self.video_bucket_to_indices = defaultdict(list)
        self.image_bucket_to_indices = defaultdict(list)
        self.gen_video_bucket_to_indices = defaultdict(list)
        self.gen_image_bucket_to_indices = defaultdict(list)

        self.task_bucket_to_indices = defaultdict(list)
        self.task_buckets = defaultdict(list)

        self.video_bucket_frames_to_indices = defaultdict(list)
        self.task_bucket_frames_to_indices = defaultdict(list)
        self.image_bucket_frames_to_indices = defaultdict(list)

        self._load_annotations(csv_path, data_root)

        self.video_buckets = sorted(self.video_bucket_to_indices.keys())
        self.image_buckets = sorted(self.image_bucket_to_indices.keys())
        self.gen_video_buckets = sorted(self.gen_video_bucket_to_indices.keys())
        self.gen_image_buckets = sorted(self.gen_image_bucket_to_indices.keys())
        for task in self.task_buckets:
            self.task_buckets[task] = sorted(self.task_buckets[task])

        if is_main_process():
            print(f"Loaded {len(self.video_data_list)} video edit, "
                  f"{len(self.image_data_list)} image edit, "
                  f"{len(self.gen_video_data_list)} video gen, "
                  f"{len(self.gen_image_data_list)} image gen samples. "
                  f"Total: {len(self.data_list)}")
            for task in sorted(self.task_buckets.keys()):
                buckets = self.task_buckets[task]
                total = sum(
                    len(self.task_bucket_to_indices[(task, b)]) for b in buckets
                )
                print(f"  Task '{task}': {total} samples across {len(buckets)} buckets")

    def _load_annotations(self, csv_paths, data_roots):
        for i, path in enumerate(csv_paths):
            file_ext = Path(path).suffix.lower()
            if file_ext == ".csv":
                df = pd.read_csv(path)
            elif file_ext in (".parquet", ".pq"):
                df = pd.read_parquet(path, engine="pyarrow")
            else:
                raise ValueError(f"Unsupported format: {file_ext}")

            has_data_type = "data_type" in df.columns
            has_task_type = "task_type" in df.columns
            has_frame_nums = "frame_nums" in df.columns

            if has_frame_nums and is_main_process():
                print(f"  [{path}] 'frame_nums' column detected — using (H, W, F) bucketing")

            if not has_data_type:
                if "video1_path" in df.columns or "video_path" in df.columns:
                    default_data_type = "video"
                elif "img1_path" in df.columns or "img_path" in df.columns:
                    default_data_type = "image"
                else:
                    raise ValueError(f"Cannot determine data type from {path}")
            else:
                default_data_type = None

            default_task_type = "tv2v" if not has_task_type else None

            for _, row in df.iterrows():
                data_type = (
                    str(row["data_type"]).lower().strip()
                    if has_data_type
                    else default_data_type
                )
                task_type = (
                    str(row["task_type"]).lower().strip()
                    if has_task_type
                    else default_task_type
                )

                # Support tv2v / ti2i / t2v / t2i / prop / i2v / keyframe
                if task_type not in ("tv2v", "ti2i", "t2v", "t2i", "prop", "i2v", "keyframe"):
                    continue

                row_frame_nums = (
                    row.get("frame_nums", None) if has_frame_nums else None
                )

                if has_frame_nums and row_frame_nums is not None and not pd.isna(row_frame_nums):
                    try:
                        int(row_frame_nums)
                    except (ValueError, TypeError):
                        continue

                # DEBUG: only keep 121-frame t2v data for VRAM testing
                if task_type == "t2v":
                    if row_frame_nums is None or pd.isna(row_frame_nums) or int(row_frame_nums) != 121:
                        continue

                data_dict = None
                if data_type == "video":
                    if task_type in ("tv2v", "prop", "i2v", "keyframe"):
                        data_dict = self._load_tv2v(row, data_roots[i], row_frame_nums)
                    elif task_type == "t2v":
                        data_dict = self._load_t2v(row, data_roots[i], row_frame_nums)
                elif data_type == "image":
                    if task_type == "ti2i":
                        data_dict = self._load_ti2i(row, data_roots[i])
                    elif task_type == "t2i":
                        data_dict = self._load_t2i(row, data_roots[i])

                if data_dict is None:
                    continue

                data_dict["index"] = len(self.data_list)
                self.data_list.append(data_dict)

                task = data_dict["task"]
                bucket = data_dict["bucket"]
                frames = data_dict.get("frames", 1)
                idx = data_dict["index"]

                task_bucket_key = (task, bucket)
                self.task_bucket_to_indices[task_bucket_key].append(idx)
                if bucket not in self.task_buckets[task]:
                    self.task_buckets[task].append(bucket)

                task_bucket_frames_key = (task, bucket, frames)
                self.task_bucket_frames_to_indices[task_bucket_frames_key].append(idx)

                if task in ("tv2v", "prop", "i2v", "keyframe"):
                    self.video_data_list.append(data_dict)
                    self.video_bucket_to_indices[bucket].append(idx)
                    self.video_bucket_frames_to_indices[(bucket, frames)].append(idx)
                elif task == "ti2i":
                    self.image_data_list.append(data_dict)
                    self.image_bucket_to_indices[bucket].append(idx)
                    self.image_bucket_frames_to_indices[(bucket, frames)].append(idx)
                elif task == "t2v":
                    self.gen_video_data_list.append(data_dict)
                    self.gen_video_bucket_to_indices[bucket].append(idx)
                elif task == "t2i":
                    self.gen_image_data_list.append(data_dict)
                    self.gen_image_bucket_to_indices[bucket].append(idx)

                if (
                    self.reconstruction_ratio > 0
                    and task in ("t2v", "t2i")
                    and random.random() < self.reconstruction_ratio
                ):
                    recon_task = "recon_v" if task == "t2v" else "recon_i"
                    recon_dict = dict(data_dict)
                    recon_dict["task"] = recon_task
                    recon_dict["type"] = "recon_video" if task == "t2v" else "recon_image"
                    recon_dict["index"] = len(self.data_list)
                    self.data_list.append(recon_dict)

                    recon_idx = recon_dict["index"]
                    recon_key = (recon_task, bucket)
                    self.task_bucket_to_indices[recon_key].append(recon_idx)
                    if bucket not in self.task_buckets[recon_task]:
                        self.task_buckets[recon_task].append(bucket)
                    recon_frames_key = (recon_task, bucket, frames)
                    self.task_bucket_frames_to_indices[recon_frames_key].append(recon_idx)

    def _load_tv2v(self, row, data_root, frame_nums=None):
        hw_bucket = row.get("bucket", None)
        video1_path = row.get("video1_path", None)
        video2_path = row.get("video2_path", None)
        instruction = row.get("editing_instruction", None) or row.get("instruction", None)
        video_caption = row.get("video2_caption", None)
        frames = row.get("frames", None)
        task_type = row.get("task_type", "tv2v")

        if pd.isna(video1_path) or pd.isna(video2_path) or pd.isna(instruction):
            return None

        if video_caption is not None and not pd.isna(video_caption):
            r = random.random()
            if r < 0.2:
                instruction = video_caption
            elif r < 0.6:
                pass
            else:
                instruction = f"{instruction} {video_caption}"

        if frame_nums is not None and not pd.isna(frame_nums):
            frames = int(frame_nums)
        else:
            frames = self.max_frames if pd.isna(frames) else int(frames)

        task = str(task_type).lower().strip() if not pd.isna(task_type) else "tv2v"
        # Allow tv2v / prop / i2v / keyframe; default back to tv2v otherwise
        if task not in ("tv2v", "prop", "i2v", "keyframe"):
            task = "tv2v"

        bucket = make_bucket_key(str(hw_bucket), frame_nums)

        return {
            "type": "video",
            "video1_path": os.path.join(data_root, video1_path) if data_root else video1_path,
            "video2_path": os.path.join(data_root, video2_path) if data_root else video2_path,
            "instruction": instruction,
            "bucket": bucket,
            "frames": frames,
            "task": task,
        }

    def _load_ti2i(self, row, data_root):
        bucket = row.get("bucket", None)
        img1_path = row.get("img1_path", None)
        img2_path = row.get("img2_path", None)
        instruction = row.get("editing_instruction", None) or row.get("instruction", None)
        img_caption = row.get("img2_caption", None)

        if pd.isna(img1_path) or pd.isna(img2_path) or pd.isna(instruction):
            return None

        if img_caption is not None and not pd.isna(img_caption):
            r = random.random()
            if r < 0.2:
                instruction = img_caption
            elif r < 0.6:
                pass
            else:
                instruction = f"{img_caption} {instruction}"

        return {
            "type": "image",
            "img1_path": os.path.join(data_root, img1_path) if data_root else img1_path,
            "img2_path": os.path.join(data_root, img2_path) if data_root else img2_path,
            "instruction": instruction,
            "bucket": str(bucket),
            "frames": 1,
            "task": "ti2i",
        }

    def _resolve_caption(self, row):
        for key in ("dense_caption", "short_caption", "caption"):
            val = row.get(key, None)
            if val is not None and not pd.isna(val):
                return val
        return None

    def _load_t2v(self, row, data_root, frame_nums=None):
        hw_bucket = row.get("bucket", None)
        video_path = row.get("video_path", None)
        caption = self._resolve_caption(row)
        frames = row.get("frames", None)

        if pd.isna(video_path) or caption is None:
            return None

        if frame_nums is not None and not pd.isna(frame_nums):
            frames = int(frame_nums)
        else:
            frames = self.max_frames if pd.isna(frames) else int(frames)

        bucket = make_bucket_key(str(hw_bucket), frame_nums)

        return {
            "type": "gen_video",
            "video_path": os.path.join(data_root, video_path) if data_root else video_path,
            "instruction": caption,
            "bucket": bucket,
            "frames": frames,
            "task": "t2v",
        }

    def _load_t2i(self, row, data_root):
        bucket = row.get("bucket", None)
        img_path = row.get("img_path", None)
        caption = self._resolve_caption(row)

        if pd.isna(img_path) or caption is None:
            return None

        return {
            "type": "gen_image",
            "img_path": os.path.join(data_root, img_path) if data_root else img_path,
            "instruction": caption,
            "bucket": str(bucket),
            "frames": 1,
            "task": "t2i",
        }

    def __len__(self):
        return len(self.data_list)

    _MAX_RETRIES = 10

    def __getitem__(self, idx):
        for attempt in range(self._MAX_RETRIES):
            data = self.data_list[idx]
            task = data["task"]
            bucket = data["bucket"]

            try:
                if task in ("tv2v", "prop", "i2v", "keyframe"):
                    return self._get_video_item(data)
                elif task == "ti2i":
                    return self._get_image_item(data)
                elif task == "t2v":
                    return self._get_gen_video_item(data)
                elif task == "t2i":
                    return self._get_gen_image_item(data)
                elif task == "recon_v":
                    return self._get_recon_video_item(data)
                elif task == "recon_i":
                    return self._get_recon_image_item(data)
                else:
                    raise ValueError(f"Unknown task: {task}")
            except Exception as e:
                print(f"[Retry {attempt+1}/{self._MAX_RETRIES}] Error loading idx={idx}: {e}")
                candidates = self.task_bucket_to_indices.get(
                    (task, bucket), []
                )
                if len(candidates) > 1:
                    idx = random.choice(candidates)
                else:
                    idx = random.randint(0, len(self.data_list) - 1)

        raise RuntimeError(
            f"Failed to load a valid sample after {self._MAX_RETRIES} retries "
            f"(last idx={idx}, task={task}, bucket={bucket})"
        )

    def _get_video_item(self, data):
        target_size = parse_bucket(data["bucket"])
        if target_size is None:
            raise ValueError(f"Invalid bucket: {data['bucket']}")

        max_frames = data.get("frames", self.max_frames)
        if not isinstance(max_frames, int):
            max_frames = self.max_frames

        video1_tensor, _ = load_video_frames(
            data["video1_path"], target_size=target_size, max_frames=max_frames,
        )
        video2_tensor, _ = load_video_frames(
            data["video2_path"], target_size=target_size, max_frames=max_frames,
        )
        if video1_tensor is None or video2_tensor is None:
            raise ValueError(f"Failed to load videos for {data['video1_path']}")

        _, video1_key_frames_numpy = load_video_key_frames(
            data["video1_path"], target_size=target_size, max_frames=max_frames,
        )
        if video1_key_frames_numpy is None:
            raise ValueError(f"Failed to load key frames from {data['video1_path']}")

        return {
            "type": "video",
            "task": data["task"],
            "video1": video1_tensor.squeeze(0),  # (C, T, H, W)
            "video2": video2_tensor.squeeze(0),  # (C, T, H, W)
            "video1_key_frames": video1_key_frames_numpy,  # (3, H, W, C) uint8
            "bucket": data["bucket"],
            "instruction": data["instruction"],
            "index": data["index"],
        }

    def _get_image_item(self, data):
        target_size = parse_bucket(data["bucket"])
        if target_size is None:
            raise ValueError(f"Invalid bucket: {data['bucket']}")

        img1_tensor, img1_numpy = load_image(data["img1_path"], target_size=target_size)
        img2_tensor, img2_numpy = load_image(data["img2_path"], target_size=target_size)
        if img1_tensor is None or img2_tensor is None:
            raise ValueError(f"Failed to load images for {data['img1_path']}")

        return {
            "type": "image",
            "task": data["task"],
            "img1": img1_tensor.squeeze(0),  # (C, 1, H, W)
            "img2": img2_tensor.squeeze(0),  # (C, 1, H, W)
            "img1_numpy": img1_numpy,  # (H, W, C) uint8
            "bucket": data["bucket"],
            "instruction": data["instruction"],
            "index": data["index"],
        }

    def _get_gen_video_item(self, data):
        target_size = parse_bucket(data["bucket"])
        if target_size is None:
            raise ValueError(f"Invalid bucket: {data['bucket']}")

        max_frames = data.get("frames", self.max_frames)
        if not isinstance(max_frames, int):
            max_frames = self.max_frames

        video_tensor, _ = load_video_frames(
            data["video_path"], target_size=target_size, max_frames=max_frames,
        )
        if video_tensor is None:
            raise ValueError(f"Failed to load video {data['video_path']}")

        return {
            "type": "gen_video",
            "task": "t2v",
            "video": video_tensor.squeeze(0),  # (C, T, H, W)
            "bucket": data["bucket"],
            "instruction": data["instruction"],
            "index": data["index"],
        }

    def _get_gen_image_item(self, data):
        target_size = parse_bucket(data["bucket"])
        if target_size is None:
            raise ValueError(f"Invalid bucket: {data['bucket']}")

        img_tensor, _ = load_image(data["img_path"], target_size=target_size)
        if img_tensor is None:
            raise ValueError(f"Failed to load image {data['img_path']}")

        return {
            "type": "gen_image",
            "task": "t2i",
            "image": img_tensor.squeeze(0),  # (C, 1, H, W)
            "bucket": data["bucket"],
            "instruction": data["instruction"],
            "index": data["index"],
        }

    def _get_recon_video_item(self, data):
        target_size = parse_bucket(data["bucket"])
        if target_size is None:
            raise ValueError(f"Invalid bucket: {data['bucket']}")

        max_frames = data.get("frames", self.max_frames)
        if not isinstance(max_frames, int):
            max_frames = self.max_frames

        video_tensor, _ = load_video_frames(
            data["video_path"], target_size=target_size, max_frames=max_frames,
        )
        if video_tensor is None:
            raise ValueError(f"Failed to load video {data['video_path']}")

        squeezed = video_tensor.squeeze(0)  # (C, T, H, W)
        return {
            "type": "recon_video",
            "task": "recon_v",
            "video1": squeezed,
            "video2": squeezed,
            "bucket": data["bucket"],
            "instruction": random.choice(self.RECONSTRUCTION_INSTRUCTIONS),
            "index": data["index"],
        }

    def _get_recon_image_item(self, data):
        target_size = parse_bucket(data["bucket"])
        if target_size is None:
            raise ValueError(f"Invalid bucket: {data['bucket']}")

        img_tensor, _ = load_image(data["img_path"], target_size=target_size)
        if img_tensor is None:
            raise ValueError(f"Failed to load image {data['img_path']}")

        squeezed = img_tensor.squeeze(0)  # (C, 1, H, W)
        return {
            "type": "recon_image",
            "task": "recon_i",
            "img1": squeezed,
            "img2": squeezed,
            "bucket": data["bucket"],
            "instruction": random.choice(self.RECONSTRUCTION_INSTRUCTIONS),
            "index": data["index"],
        }
